<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from puikinsh.github.io/login-forms/forms/corporate/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Sep 2025 17:48:05 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.8/css/bootstrap.min.css" integrity="sha512-2bBQCjcnw658Lho4nlXJcc6WkV/UxpE/sAokbXPxQNGqmNdQrWqtw26Ns9kFF/yG792pKR1Sx8/Y1Lf1XN4GKA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('login/style.css')); ?>">
    <style>
        .form-group{
            margin-bottom: 18px !important;
        }
        /* Corporate Login Form - Complete & Self-Contained */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            line-height: 1.6;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
        }

        .login-card {
            background: #ffffff;
            border: 1px solid #e1e5e9;
            border-radius: 12px;
            padding: 40px;
            box-shadow:
                0 10px 25px rgba(0, 0, 0, 0.1),
                0 20px 48px rgba(0, 0, 0, 0.1);
            position: relative;
            transition: all 0.3s ease;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #2563eb, #3b82f6, #1d4ed8);
            border-radius: 12px 12px 0 0;
        }

        .login-card:hover {
            box-shadow:
                0 15px 35px rgba(0, 0, 0, 0.15),
                0 25px 60px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }

        .login-header {
            text-align: center;
            margin-bottom: 36px;
        }

        .company-logo {
            margin-bottom: 20px;
        }

        .logo-icon {
            display: inline-block;
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #2563eb, #3b82f6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        .login-header h2 {
            color: #1e293b;
            font-size: 1.875rem;
            font-weight: 600;
            margin-bottom: 8px;
            letter-spacing: -0.025em;
        }

        .login-header p {
            color: #64748b;
            font-size: 15px;
            font-weight: 400;
        }

        /* Form Group & Input Styles */
        .form-group {
            margin-bottom: 24px;
            position: relative;
        }

        .input-wrapper {
            position: relative;
            display: flex;
            flex-direction: column;
        }

        .input-wrapper input {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px 16px;
            color: #1e293b;
            font-size: 16px;
            font-weight: 400;
            transition: all 0.3s ease;
            width: 100%;
            outline: none;
        }

        .input-wrapper input:focus {
            background: #ffffff;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .input-wrapper input:focus + label,
        .input-wrapper input:valid + label {
            transform: translateY(-36px) translateX(4px) scale(0.85);
            color: #2563eb;
            font-weight: 600;
            background: #ffffff;
            padding: 0 8px;
        }

        .input-wrapper label {
            position: absolute;
            left: 16px;
            top: 16px;
            color: #64748b;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s ease;
            pointer-events: none;
            transform-origin: left top;
        }

        .input-border {
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, #2563eb, #3b82f6);
            transition: all 0.3s ease;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        .input-wrapper input:focus ~ .input-border {
            width: 100%;
        }

        /* Password Toggle */
        .password-wrapper input {
            padding-right: 50px;
        }

        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            color: #64748b;
            transition: all 0.3s ease;
            border-radius: 6px;
            z-index: 2;
        }

        .password-toggle:hover {
            color: #2563eb;
            background: rgba(37, 99, 235, 0.1);
        }

        .toggle-icon {
            display: block;
            width: 18px;
            height: 18px;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b' stroke-width='1.5'%3e%3cpath stroke-linecap='round' stroke-linejoin='round' d='M15 12a3 3 0 11-6 0 3 3 0 016 0z'/%3e%3cpath stroke-linecap='round' stroke-linejoin='round' d='M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z'/%3e%3c/svg%3e");
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            transition: background-image 0.3s ease;
        }

        .password-toggle:hover .toggle-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%232563eb' stroke-width='1.5'%3e%3cpath stroke-linecap='round' stroke-linejoin='round' d='M15 12a3 3 0 11-6 0 3 3 0 016 0z'/%3e%3cpath stroke-linecap='round' stroke-linejoin='round' d='M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z'/%3e%3c/svg%3e");
        }

        .toggle-icon.show-password {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b' stroke-width='1.5'%3e%3cpath stroke-linecap='round' stroke-linejoin='round' d='M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 11-4.243-4.243m4.242 4.242L9.88 9.88'/%3e%3c/svg%3e");
        }

        /* Form Options */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .remember-wrapper {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .remember-wrapper input[type="checkbox"] {
            display: none;
        }

        .checkbox-custom {
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e1;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            flex-shrink: 0;
            background: #ffffff;
        }

        .remember-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom {
            background: #2563eb;
            border-color: #2563eb;
            transform: scale(1.05);
        }

        .remember-wrapper input[type="checkbox"]:checked + .checkbox-label .checkbox-custom::after {
            content: '✓';
            color: white;
            font-size: 12px;
            font-weight: bold;
        }

        .checkbox-label {
            color: #475569;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            user-select: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: color 0.3s ease;
        }

        .remember-wrapper:hover .checkbox-label {
            color: #2563eb;
        }

        .forgot-password {
            color: #2563eb;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
        }

        .forgot-password::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: #2563eb;
            transition: width 0.3s ease;
        }

        .forgot-password:hover::after {
            width: 100%;
        }

        .forgot-password:hover {
            color: #1d4ed8;
        }

        /* Login Button */
        .login-btn {
            width: 100%;
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            border: none;
            border-radius: 8px;
            padding: 16px 24px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            margin-bottom: 24px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        .login-btn:hover {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        /* Loading State */
        .login-btn.loading {
            pointer-events: none;
            background: #94a3b8;
        }

        .btn-text {
            transition: opacity 0.3s ease;
        }

        .btn-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 18px;
            height: 18px;
            border: 2px solid transparent;
            border-top: 2px solid white;
            border-radius: 50%;
            opacity: 0;
            animation: spin 1s linear infinite;
            transition: opacity 0.3s ease;
        }

        .login-btn.loading .btn-text {
            opacity: 0;
        }

        .login-btn.loading .btn-loader {
            opacity: 1;
        }

        /* Divider */
        .divider {
            text-align: center;
            margin: 24px 0;
            position: relative;
        }

        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e2e8f0;
            transform: translateY(-50%);
        }

        .divider span {
            background: #ffffff;
            color: #64748b;
            padding: 0 20px;
            font-size: 13px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: relative;
            z-index: 1;
        }

        /* SSO Options */
        .sso-options {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 24px;
        }

        .sso-btn {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            padding: 14px 20px;
            color: #475569;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .sso-btn:hover {
            background: #ffffff;
            border-color: #cbd5e1;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .sso-icon {
            width: 20px;
            height: 20px;
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
        }

        .azure-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%230078d4' d='M13.55 4.615L8.326 15.632 2.11 17.706l14.805-1.923L13.55 4.615zm4.234 12.83L5.813 19.389 12.095 6.85l5.689 10.595z'/%3e%3c/svg%3e");
        }

        .okta-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3e%3cpath fill='%2300297a' d='M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 16c-3.314 0-6-2.686-6-6s2.686-6 6-6 6 2.686 6 6-2.686 6-6 6z'/%3e%3c/svg%3e");
        }

        /* Footer Links */
        .footer-links {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }

        .footer-link {
            color: #64748b;
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .footer-link:hover {
            color: #2563eb;
        }

        .separator {
            color: #cbd5e1;
            margin: 0 8px;
            font-size: 12px;
        }

        /* Error States */
        .error-message {
            color: #dc2626;
            font-size: 12px;
            font-weight: 500;
            margin-top: 6px;
            margin-left: 4px;
            opacity: 0;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            background: rgba(220, 38, 38, 0.05);
            padding: 4px 8px;
            border-radius: 4px;
            border-left: 3px solid #dc2626;
        }

        .error-message.show {
            opacity: 1;
            transform: translateY(0);
        }

        .form-group.error .input-wrapper input {
            border-color: #dc2626;
            background: rgba(220, 38, 38, 0.05);
            box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1);
        }

        /* Success Message */
        .success-message {
            display: none;
            text-align: center;
            padding: 36px 20px;
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.5s ease;
        }

        .success-message.show {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        .success-icon {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, #059669, #10b981);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
            margin: 0 auto 20px;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
        }

        .success-message h3 {
            color: #1e293b;
            font-size: 1.375rem;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .success-message p {
            color: #64748b;
            font-size: 15px;
        }

        /* Animations */
        @keyframes  spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }

        /* Mobile Responsive */
        @media (max-width: 480px) {
            body {
                padding: 16px;
            }

            .login-card {
                padding: 28px;
            }

            .login-header h2 {
                font-size: 1.625rem;
            }

            .company-logo {
                margin-bottom: 16px;
            }

            .logo-icon {
                width: 56px;
                height: 56px;
                font-size: 20px;
            }

            .form-options {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }

            .sso-options {
                gap: 10px;
            }

            .footer-links {
                font-size: 11px;
            }
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <div class="login-header">

            <h2>Welcome Back</h2>
            <p>Please sign in to your account</p>
        </div>
        
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <b>Sorry!</b> <?php echo e(session('error')); ?>

            </div>
            <br>
        <?php endif; ?>
        <form class="login-form" id="loginForm" method="post" action="<?php echo e(route('loginSubmit')); ?>" novalidate>

            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('email')? 'error' : ''); ?>">
                <div class="input-wrapper">
                    <input type="email" id="email" name="email"  autocomplete="email" value="<?php echo e(old('email')); ?>">
                    <label for="email">Business Email</label>
                    <span class="input-border"></span>
                </div>
                <span class="error-message <?php echo e($errors->has('email') ? 'show' : ''); ?>" id="emailError"><?php echo e($errors->first('email')); ?></span>
            </div>

            <div class="form-group <?php echo e($errors->has('password') ? 'error' : ''); ?>">
                <div class="input-wrapper password-wrapper">
                    <input type="password" id="password" name="password"  autocomplete="current-password">
                    <label for="password">Password</label>
                    <button type="button" class="password-toggle" id="passwordToggle" aria-label="Toggle password visibility">
                        <span class="toggle-icon"></span>
                    </button>
                    <span class="input-border"></span>
                </div>
                <span class="error-message <?php echo e($errors->has('password') ? 'show': ''); ?>" id="passwordError"><?php echo e($errors->first('password')); ?></span>
            </div>

            

            <button type="submit" class="login-btn">
                <span class="btn-text">Sign In</span>
                <span class="btn-loader"></span>
            </button>
        </form>
    </div>
</div>

<script src="<?php echo e(asset('login/form-utils.js')); ?>"></script>
<script>
    class CorporateLoginForm {
        constructor() {
            this.form = document.getElementById('loginForm');
            this.emailInput = document.getElementById('email');
            this.passwordInput = document.getElementById('password');
            this.passwordToggle = document.getElementById('passwordToggle');
            this.submitButton = this.form.querySelector('.login-btn');
            this.successMessage = document.getElementById('successMessage');
            this.ssoButtons = document.querySelectorAll('.sso-btn');

            this.init();
        }
        init() {
            this.bindEvents();
            this.setupPasswordToggle();
            this.setupSSOButtons();
        }
        bindEvents() {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
            //his.emailInput.addEventListener('blur', () => this.validateEmail());
            //this.passwordInput.addEventListener('blur', () => this.validatePassword());
            //this.emailInput.addEventListener('input', () => this.clearError('email'));
            //this.passwordInput.addEventListener('input', () => this.clearError('password'));
        }

        setupPasswordToggle() {
            this.passwordToggle.addEventListener('click', () => {
                const type = this.passwordInput.type === 'password' ? 'text' : 'password';
                this.passwordInput.type = type;

                const icon = this.passwordToggle.querySelector('.toggle-icon');
                icon.classList.toggle('show-password', type === 'text');
            });
        }

        setupSSOButtons() {
            this.ssoButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    const provider = button.classList.contains('azure-btn') ? 'Azure AD' : 'Okta';
                    this.handleSSOLogin(provider);
                });
            });
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        new CorporateLoginForm();
    });

</script>

</body>

<!-- Mirrored from puikinsh.github.io/login-forms/forms/corporate/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Sep 2025 17:48:05 GMT -->
</html>
<?php /**PATH D:\laravel\nn_pos\resources\views/login.blade.php ENDPATH**/ ?>