<?php

namespace App\Http\Controllers;

use App\Models\Godown;
use Illuminate\Http\Request;

class GodownController extends Controller
{
    public function index(){
        $godowns = Godown::all();
        $last_id = Godown::orderBy('id', 'desc')->first();
        $last_id = $last_id->id + 1;
        return view('admin.goddown.goddown')->with(['godowns'=>$godowns,'last_id'=>$last_id] );
    }

    public function addGoddown(Request $request){
        $request->validate([
            'name' => 'required',
        ]);
        $godown = new Godown();
        $godown->name = $request->name;
        $save = $godown->save();
        if($save){
            return redirect()->route('goddown')->with('success','Godown added successfully');
        }else{
            return redirect()->route('goddown')->with('error','Something went wrong');
        }


    }
}
