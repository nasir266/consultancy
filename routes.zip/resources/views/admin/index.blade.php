@extends('layouts.master')

@section('title','Home page')

@section('tailwind')
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style type="text/tailwindcss">
        @theme {
            --color-clifford: #da373d;
        }
    </style>

@endsection
@section('styles')

    <style>
        #mobile-label .flex-wrap{
            flex-wrap: nowrap;
        }
        #mobile-label button{
            font-size: 12px;
        }
    </style>

@endsection

@section('content')
    <div class="p-2.5 md:p-6">
        <div class="grid grid-cols-4">

            <div class="w-full lg:w-6/12 xl:w-3/12 px-4">

                <div class="relative flex flex-col min-w-0 break-words bg-gray-200 rounded mb-6 xl:mb-0 shadow-lg">
                    <div class="flex-auto p-4">
                        <div class="flex flex-wrap">
                            <div class="relative w-full pr-4 max-w-full flex-grow flex-1">
                                <h5 class="text-blueGray-400 uppercase font-bold text-xs">TOTAL PARTY</h5>
                                <span class="font-semibold text-xl text-blueGray-700">{{$total_party}}</span>
                            </div>
                            <div class="relative w-auto pl-4 flex-initial">
                                <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-blue-500">
                                    <i class="far fa-user"></i>
                                </div>
                            </div>
                        </div>
                        {{--<p class="text-sm text-blueGray-400 mt-4">
                            <span class="text-emerald-500 mr-2">
                                <i class="fas fa-arrow-up"></i> <!-- -->3.48<!-- -->%
                            </span>
                            <span class="whitespace-nowrap">Since last month</span>
                        </p>--}}
                    </div>
                </div>
            </div>

            <div class="w-full lg:w-6/12 xl:w-3/12 px-4">

                <div class="relative flex flex-col min-w-0 break-words bg-gray-200 rounded mb-6 xl:mb-0 shadow-lg">
                    <div class="flex-auto p-4">
                        <div class="flex flex-wrap">
                            <div class="relative w-full pr-4 max-w-full flex-grow flex-1">
                                <h5 class="text-blueGray-400 uppercase font-bold text-xs">TOTAL ITEMS</h5>
                                <span class="font-semibold text-xl text-blueGray-700">{{$total_item}}</span>
                            </div>
                            <div class="relative w-auto pl-4 flex-initial">
                                <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-blue-500">
                                    <i class="far fa-chart-bar"></i>
                                </div>
                            </div>
                        </div>
                        {{--<p class="text-sm text-blueGray-400 mt-4">
                            <span class="text-emerald-500 mr-2">
                                <i class="fas fa-arrow-up"></i> <!-- -->3.48<!-- -->%
                            </span>
                            <span class="whitespace-nowrap">Since last month</span>
                        </p>--}}
                    </div>
                </div>
            </div>

            <div class="w-full lg:w-6/12 xl:w-3/12 px-4">

                <div class="relative flex flex-col min-w-0 break-words bg-gray-200 rounded mb-6 xl:mb-0 shadow-lg">
                    <div class="flex-auto p-4">
                        <div class="flex flex-wrap">
                            <div class="relative w-full pr-4 max-w-full flex-grow flex-1">
                                <h5 class="text-blueGray-400 uppercase font-bold text-xs">TOTAL CITIES</h5>
                                <span class="font-semibold text-xl text-blueGray-700">{{$total_city}}</span>
                            </div>
                            <div class="relative w-auto pl-4 flex-initial">
                                <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-blue-500">
                                    <i class="far fa-chart-bar"></i>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="w-full lg:w-6/12 xl:w-3/12 px-4">

                <div class="relative flex flex-col min-w-0 break-words bg-gray-200 rounded mb-6 xl:mb-0 shadow-lg">
                    <div class="flex-auto p-4">
                        <div class="flex flex-wrap">
                            <div class="relative w-full pr-4 max-w-full flex-grow flex-1">
                                <h5 class="text-blueGray-400 uppercase font-bold text-xs">TOTAL INVOICE</h5>
                                <span class="font-semibold text-xl text-blueGray-700">{{$total_invoice}}</span>
                            </div>
                            <div class="relative w-auto pl-4 flex-initial">
                                <div class="text-white p-3 text-center inline-flex items-center justify-center w-12 h-12 shadow-lg rounded-full bg-blue-500">
                                    <i class="far fa-chart-bar"></i>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
        <!--end row-->
        <div class="grid grid-cols-2 grid-rows-2    h-screen">

            <div class="relative flex flex-col rounded-xl bg-gray-200 bg-clip-border text-gray-700 shadow-md mx-4">
                <div class="relative mx-4 mt-4 flex flex-col gap-4 overflow-hidden rounded-none bg-transparent bg-clip-border text-gray-700 shadow-none md:flex-row md:items-center">

                    <h5 class="text-blueGray-400 uppercase font-bold text-xl">TOTAL INVOICE</h5>
                </div>
                <div class="pt-6 px-2 pb-0">
                    <div id="bar-chart"></div>
                </div>
            </div>

            <div class="relative flex flex-col rounded-xl bg-gray-200 bg-clip-border text-gray-700 shadow-md mx-4">
                <div class="relative mx-4 mt-4 flex flex-col gap-4 overflow-hidden rounded-none bg-transparent bg-clip-border text-gray-700 shadow-none md:flex-row md:items-center">

                    <div>
                        <h5 class="text-blueGray-400 uppercase font-bold text-xl">TOTAL PARTY</h5>

                    </div>
                </div>
                <div class="pt-6 px-2 pb-0">
                    <div id="line-chart"></div>
                </div>
            </div>

        </div>
        {{--row end --}}

    </div>





    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script>


        const chartConfig = {
            series: [
                {
                    name: "Sales",
                    data: [50, 40, 300, 320, 500, 350, 200, 230, 500],
                },
            ],
            chart: {
                type: "bar",
                height: 240,
                toolbar: {
                    show: false,
                },
            },
            title: {
                show: "",
            },
            dataLabels: {
                enabled: false,
            },
            colors: ["#2731F5"],
            plotOptions: {
                bar: {
                    columnWidth: "40%",
                    borderRadius: 2,
                },
            },
            xaxis: {
                axisTicks: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                labels: {
                    style: {
                        colors: "blue",
                        fontSize: "12px",
                        fontFamily: "inherit",
                        fontWeight: 400,
                    },
                },
                categories: [
                    "Apr",
                    "May",
                    "Jun",
                    "Jul",
                    "Aug",
                    "Sep",
                    "Oct",
                    "Nov",
                    "Dec",
                ],
            },
            yaxis: {
                labels: {
                    style: {
                        colors: "blue",
                        fontSize: "12px",
                        fontFamily: "inherit",
                        fontWeight: 400,
                    },
                },
            },
            grid: {
                show: true,
                borderColor: "#dddddd",
                strokeDashArray: 5,
                xaxis: {
                    lines: {
                        show: true,
                    },
                },
                padding: {
                    top: 5,
                    right: 20,
                },
            },
            fill: {
                opacity: 0.8,
            },
            tooltip: {
                theme: "dark",
            },
        };

        const chart = new ApexCharts(document.querySelector("#bar-chart"), chartConfig);

        chart.render();
    </script>

    <script>
        const lineChartConfig = {
            series: [
                {
                    name: "Sales",
                    data: [50, 40, 300, 320, 500, 350, 200, 230, 500],
                },
            ],
            chart: {
                type: "line",
                height: 240,
                toolbar: {
                    show: false,
                },
            },
            title: {
                show: "",
            },
            dataLabels: {
                enabled: false,
            },
            colors: ["#2731F5"],
            stroke: {
                lineCap: "round",
                curve: "smooth",
            },
            markers: {
                size: 0,
            },
            xaxis: {
                axisTicks: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                labels: {
                    style: {
                        colors: "blue",
                        fontSize: "12px",
                        fontFamily: "inherit",
                        fontWeight: 400,
                    },
                },
                categories: [
                    "Apr",
                    "May",
                    "Jun",
                    "Jul",
                    "Aug",
                    "Sep",
                    "Oct",
                    "Nov",
                    "Dec",
                ],
            },
            yaxis: {
                labels: {
                    style: {
                        colors: "blue",
                        fontSize: "12px",
                        fontFamily: "inherit",
                        fontWeight: 400,
                    },
                },
            },
            grid: {
                show: true,
                borderColor: "#dddddd",
                strokeDashArray: 5,
                xaxis: {
                    lines: {
                        show: true,
                    },
                },
                padding: {
                    top: 5,
                    right: 20,
                },
            },
            fill: {
                opacity: 0.8,
            },
            tooltip: {
                theme: "dark",
            },
        };

        const lineChart = new ApexCharts(document.querySelector("#line-chart"), lineChartConfig);

        lineChart.render();
    </script>
@endsection


@section('scripts')



@endsection
