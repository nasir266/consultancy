@extends('layouts.master')

@section('title','Sales Invoice')

@section('content')

<div class="p-2.5 md:p-6 text-[13px] lg:text-base">
    <form action="#" class="bg-white rounded-xl p-5 block">
      <div class="flex flex-wrap items-end gap-4">
        <div class="space-y-4">
          <div class="flex items-center flex-wrap gap-3 max-w-[500px]">
            <div class="flex-1">
              <label
                for="bill"
                class="block font-medium text-gray-600 mb-1"
                >Bill #</label
              >
              <input
                id="bill"
                type="number"
                class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
                placeholder="Bill #"
              />
            </div>
            <div class="flex-1">
              <label for="vr" class="block font-medium text-gray-600 mb-1"
                >Vr #</label
              >
              <input
                id="vr"
                type="number"
                class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
                placeholder="Vr #"
              />
            </div>
          </div>

          <div class="flex items-center flex-wrap gap-3 max-w-[500px]">
            <div class="flex-1">
              <label
                for="bilty"
                class="block font-medium text-gray-600 mb-1"
                >Bilty #</label
              >
              <input
                id="bilty"
                type="number"
                class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
                placeholder="Bilty #"
              />
            </div>
            <div class="flex-1">
              <label
                for="date"
                class="block font-medium text-gray-600 mb-1"
                >Date</label
              >
              <input
                id="date"
                type="date"
                class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
          </div>
        </div>
        <div class="flex gap-2.5 items-center">
          <button
            type="button"
            class="px-4 py-1 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
          >
            Purchase
          </button>
          <button
            type="button"
            onclick="openModal(event, 'item-search-model')"
            class="px-4 py-1 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
          >
            Item Search
          </button>
          <a
            href="../"
            class="block px-4 py-1 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
          >
            Add Party
          </a>
        </div>
      </div>
      <div class="mt-4 max-w-[700px] space-y-4">
        <div class="flex items-center gap-4">
          <div class="flex-1">
            <label
              for="s-part"
              class="block text-gray-600 font-medium mb-1"
              >Party Name</label
            >
            <select
              class="selectize-input-sp w-full"
              name="s-part"
              id="s-part"
            >
              <option value="">Party Name</option>
            </select>
          </div>
          <div class="w-[70px]">
            <label for="id" class="block text-gray-600 font-medium mb-1"
              >ID</label
            >
            <input
              id="id"
              type="number"
              class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
              placeholder="ID"
            />
          </div>
        </div>
        <div>
          <label
            for="address"
            class="block text-gray-600 font-medium mb-1"
            >Address</label
          >
          <input
            id="address"
            type="text"
            class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
            placeholder="Address"
          />
        </div>
        <div class="flex items-center gap-3 flex-wrap">
          <div class="lg:flex-1">
            <label for="city" class="block text-gray-600 font-medium mb-1"
              >City</label
            >
            <input
              id="city"
              type="text"
              class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              placeholder="City"
            />
          </div>
          <div class="lg:flex-1">
            <label
              for="mobile"
              class="block text-gray-600 font-medium mb-1"
              >Mobile</label
            >
            <input
              id="mobile"
              type="text"
              class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              placeholder="Mobile"
            />
          </div>
          <div class="lg:flex-1">
            <label
              for="goddown-s"
              class="block text-gray-600 font-medium mb-1"
              >Goddown</label
            >
            <select
              name="goddown-s"
              id="goddown-s"
              class="goddown-s border border-gray-300 w-full transition-all ease-in-out duration-200 focus:outline-indigo-500 px-4 py-1.5 rounded-md"
            >
              <option value="" selected disabled>Goddown</option>
              <option value="">My Party</option>
            </select>
          </div>
        </div>
        <div>
          <label for="remark" class="block text-gray-600 font-medium mb-1"
            >Remark</label
          >
          <input
            id="remark"
            type="text"
            class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
            placeholder="Remark"
          />
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-2 mt-4">
        <div class="w-full max-w-[100px]">
          <label
            for="barcode"
            class="block font-medium text-gray-600 mb-1"
            >Barcode</label
          >
          <input
            id="barcode"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Barcode"
          />
        </div>
        <div class="w-full max-w-[100px]">
          <label for="i-code" class="block font-medium text-gray-600 mb-1"
            >Itemcode</label
          >

          <input
            id="i-code"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Itemcode"
          />
        </div>
        <div class="w-full max-w-[280px]">
          <label
            for="description"
            class="block font-medium text-gray-600 mb-1"
            >Description</label
          >
          <input
            id="description"
            type="text"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Description"
          />
        </div>
        <div class="w-full max-w-[70px]">
          <label for="pcs" class="block font-medium text-gray-600 mb-1"
            >Pcs</label
          >
          <input
            id="pcs"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Pcs"
          />
        </div>
        <div class="w-full max-w-[70px]">
          <label for="rate" class="block font-medium text-gray-600 mb-1"
            >Rate</label
          >
          <input
            id="rate"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Rate"
          />
        </div>
        <div class="w-full max-w-[70px]">
          <label for="amount" class="block font-medium text-gray-600 mb-1"
            >Amount</label
          >
          <input
            id="amount"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Amount"
          />
        </div>
        <div class="w-full max-w-[70px]">
          <label for="less" class="block font-medium text-gray-600 mb-1"
            >Less</label
          >
          <input
            id="less"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Less"
          />
        </div>
        <div class="w-full max-w-[70px]">
          <label for="l-rate" class="block font-medium text-gray-600 mb-1"
            >L Rate</label
          >
          <input
            id="l-rate"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="L Rate"
          />
        </div>
        <div class="w-full max-w-[90px]">
          <label for="g-rate" class="block font-medium text-gray-600 mb-1"
            >G Amount</label
          >
          <input
            id="g-rate"
            type="number"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="G Amount"
          />
        </div>
      </div>

      <div class="mt-4">
        <div class="w-full max-w-[200px] mb-4">
          <label for="search" class="block text-gray-600 font-medium mb-1"
            >Search</label
          >
          <input
            id="search"
            type="text"
            class="no-arrows border w-full border-gray-300 transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-2 py-1 rounded-md"
            placeholder="Search"
          />
        </div>
        <div class="flex gap-3 flex-wrap items-end overflow-x-auto pb-3">
          <div class="flex-grow flex-shrink-0">
            <table
              class="table-auto w-full border-collapse border text-sm"
            >
              <thead class="bg-gray-50 text-gray-500 font-medium">
                <tr>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Barcode
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    P Item Code
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Description
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Godown
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Pkt Qty
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Pcs in Pkt
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Total Pcs
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    P Rate
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Amount
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Less / pcs
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Dis / pcs
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    L Rate
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    G Amount
                  </th>
                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Total Less
                  </th>

                  <th class="border border-gray-200 px-3 py-2 text-left">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="flex gap-5 flex-wrap mt-8">
        <div
          class="flex items-center flex-col gap-3 flex-grow md:flex-1 md:max-w-72"
        >
          <label
            for="file"
            class="flex items-center justify-center gap-2 flex-col w-full cursor-pointer transition-colors hover:bg-red-50 h-32 p-2 border-2 border-dashed border-red-300 rounded-xl"
          >
            <input
              id="file"
              type="file"
              class="hidden"
              onchange="uploadFile(event,'file-preview')"
            />
            <i class="fa-regular fa-file text-5xl text-red-400"></i>
            <img
              id="file-preview"
              class="block hidden w-full h-full object-cover rounded-md"
              alt=""
            />
            <span class="block text-xs font-medium text-red-400 underline"
              >Upload File</span
            >
          </label>
          <button
            class="flex items-center justify-center gap-2 flex-col w-full cursor-pointer transition-colors hover:bg-red-50 h-32 p-2 border-2 border-dashed border-red-300 rounded-xl"
            type="button"
            onclick="opneCam(event, 'file-preview')"
          >
            <i class="fa-solid fa-camera text-4xl text-red-400"></i>
            <span class="block text-xs font-medium text-red-400 underline"
              >Open Camera</span
            >
          </button>
        </div>
        <div class="flex-grow md:flex-1 space-y-4">
          <div class="flex items-center flex-wrap lg:flex-nowrap gap-3">
            <div class="flex-grow md:flex-1">
              <label
                for="t-pkt"
                class="block font-medium text-gray-600 mb-1"
                >Total Qty</label
              >
              <input
                id="t-pkt"
                type="text"
                placeholder="Total Qty"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
            <div class="flex-grow md:flex-1">
              <label
                for="amount-2"
                class="block font-medium text-gray-600 mb-1"
                >Amount</label
              >
              <input
                id="amount-2"
                type="text"
                placeholder="Amount"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
            <div class="flex-grow md:flex-1">
              <label
                for="less-2"
                class="block font-medium text-gray-600 mb-1"
                >Less</label
              >
              <input
                id="less-2"
                type="text"
                placeholder="Less"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
            <div class="flex-grow md:flex-1">
              <label
                for="g-amount-2"
                class="block font-medium text-gray-600 mb-1"
                >G Amount</label
              >
              <input
                id="g-amount-2"
                type="text"
                placeholder="G Amount"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
          </div>

          <div
            class="flex items-center flex-wrap lg:flex-nowrap gap-3 ml-auto max-w-[441px]"
          >
            <div class="flex-grow md:flex-1">
              <label
                for="desc"
                class="block font-medium text-gray-600 mb-1"
                >Desc %</label
              >
              <input
                id="desc"
                type="number"
                placeholder="Desc %"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
            <div class="flex-grow md:flex-1">
              <label
                for="n-amount"
                class="block font-medium text-gray-600 mb-1"
                >Net Amount</label
              >
              <input
                id="n-amount"
                type="number"
                placeholder="Net Amount"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
          </div>

          <div class="flex items-center flex-wrap lg:flex-nowrap gap-3">
            <div
              class="flex items-center flex-1 justify-end gap-4 lg:mt-6 mr-4"
            >
              <div class="flex items-center gap-2">
                <label for="cash" class="text-gray-600 text-xl"
                  >Cash</label
                >
                <input
                  type="radio"
                  name="payment-m"
                  checked
                  id="cash"
                  class="accent-indigo-600 w-3 h-3"
                />
              </div>
              <div class="flex items-center gap-2">
                <label for="credit" class="text-gray-600 text-xl"
                  >Credit</label
                >
                <input
                  type="radio"
                  name="payment-m"
                  id="credit"
                  class="accent-indigo-600 w-3 h-3"
                />
              </div>
            </div>
            <div class="flex items-center gap-3 ml-auto max-w-[441px]">
              <div class="flex-grow md:flex-1">
                <label
                  for="freight"
                  class="block font-medium text-gray-600 mb-1"
                  >Freight</label
                >
                <input
                  id="freight"
                  type="text"
                  placeholder="Freight"
                  class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
                />
              </div>
              <div class="flex-grow md:flex-1">
                <label
                  for="paid-amount"
                  class="block font-medium text-gray-600 mb-1"
                  >Paid Amount</label
                >
                <input
                  id="paid-amount"
                  type="number"
                  placeholder="Paid Amount"
                  class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
                />
              </div>
            </div>
          </div>
          <div
            class="flex items-center flex-wrap lg:flex-nowrap gap-3 ml-auto max-w-[441px]"
          >
            <div class="flex-grow md:flex-1">
              <label
                for="t-less"
                class="block font-medium text-gray-600 mb-1"
                >Total Less</label
              >
              <input
                id="t-less"
                type="text"
                placeholder="Total Less"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
            <div class="flex-grow md:flex-1">
              <label
                for="total-amount"
                class="block font-medium text-gray-600 mb-1"
                >Total Amount</label
              >
              <input
                id="total-amount"
                type="text"
                placeholder="Total Amount"
                class="border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-4 py-1 rounded-md"
              />
            </div>
          </div>
        </div>
      </div>
      <div class="mt-8 flex items-center gap-2 justify-end">
        <div class="flex items-center flex-wrap gap-3">
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="reset"
          >
            <i data-feather="refresh-ccw" class="w-4 h-4 mr-3"></i>
            Reset
          </button>
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="submit"
          >
            <i data-feather="chevrons-up" class="w-4 h-4 mr-3"></i>
            Update
          </button>
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="submit"
          >
            <i data-feather="save" class="w-4 h-4 mr-3"></i>
            Save
          </button>
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="button"
          >
            <i data-feather="printer" class="w-4 h-4 mr-3"></i>
            Print
          </button>
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="button"
          >
            <i data-feather="codesandbox" class="w-4 h-4 mr-3"></i>
            Barcode
          </button>
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="button"
          >
            <i data-feather="trash-2" class="w-4 h-4 mr-3"></i>
            Delete
          </button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>

@endsection


