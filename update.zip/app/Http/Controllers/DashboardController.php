<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Stock;
use App\Models\Category;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;


class DashboardController extends Controller
{
    //

}
