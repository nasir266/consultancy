<?php

namespace App\Http\Controllers;

use App\Models\City;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function fetchCity(Request $request){
        $allCity = City::all();
        return view('admin.city.city', ['allCity' => $allCity]);
    }
}
