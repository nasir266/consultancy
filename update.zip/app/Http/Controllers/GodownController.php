<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GodownController extends Controller
{
    //
}
