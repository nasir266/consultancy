@extends('layouts.master')

@section('title','Goddown')

@section('content')

<div class="p-2.5 md:px-5 md:py-4 text-[13px] lg:text-base">
    <form action="#" class="p-5 md:py-8 bg-white rounded-xl">
      <div class="space-y-5">
        <div class="space-y-3">
          <div class="max-w-[700px]">
            <label for="id" class="block text-gray-600 font-medium mb-1"
              >ID</label
            >
            <input
              id="id"
              type="number"
              class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-5 py-2.5 rounded-md"
              placeholder="eg; 17"
            />
          </div>
          <div class="max-w-[700px]">
            <label for="name" class="block text-gray-600 font-medium mb-1"
              >Goddown Name</label
            >
            <input
              id="name"
              type="text"
              class="no-arrows border border-gray-300 w-full transition-all ease-in-out duration-200 focus:border-none focus:outline-indigo-500 px-5 py-2.5 rounded-md"
              placeholder="enter name"
            />
          </div>
        </div>
        <div class="flex items-center flex-wrap gap-3">
          <button
            class="flex items-center px-3 py-1.5 transition-colors duration-200 bg-indigo-600 border border-indigo-600 text-white rounded-lg hover:bg-transparent hover:text-indigo-600"
            type="submit"
          >
            <i data-feather="chevrons-up" class="w-4 h-4 mr-3"></i>
            Submit
          </button>
        </div>
      </div>
    </form>
    <div class="p-5 bg-white rounded-xl mt-4">
      <div class="flex gap-3 flex-wrap items-end overflow-x-auto pb-3">
        <div class="flex-grow flex-shrink-0">
          <table class="table-auto w-full border-collapse border text-sm">
            <thead class="bg-gray-50 text-gray-500 font-normal">
              <tr>
                <th class="border border-gray-200 px-4 py-3 text-left">
                  ID
                </th>
                <th class="border border-gray-200 px-4 py-3 text-left">
                  Godown Name
                </th>
                <th class="border border-gray-200 px-4 py-3 text-left">
                  Default
                </th>
                <th class="border border-gray-200 px-4 py-3 text-left">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="border border-gray-200 px-4 py-3">1</td>
                <td class="border border-gray-200 px-4 py-3">
                  MAIN SHOP
                </td>
                <td class="border border-gray-200 px-4 py-3">
                  <a href="#" class="text-indigo-600">Make Default</a>
                </td>
                <td class="border border-gray-200 px-4 py-3">
                  <div class="flex items-center gap-3">
                    <a href="#" class="text-indigo-600">
                      <i data-feather="edit-2" class="w-4 h-4"></i>
                    </a>
                    <a href="#" class="text-red-600">
                      <i data-feather="trash-2" class="w-4 h-4"></i>
                    </a>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection


