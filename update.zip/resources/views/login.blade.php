<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from puikinsh.github.io/login-forms/forms/corporate/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Sep 2025 17:48:05 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Corporate Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.8/css/bootstrap.min.css" integrity="sha512-2bBQCjcnw658Lho4nlXJcc6WkV/UxpE/sAokbXPxQNGqmNdQrWqtw26Ns9kFF/yG792pKR1Sx8/Y1Lf1XN4GKA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('login/style.css') }}">
    <style>
        .form-group{
            margin-bottom: 18px !important;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <div class="login-header">

            <h2>Welcome Back</h2>
            <p>Please sign in to your corporate account</p>
        </div>
        {{--@if($errors != '')
            {{print_r($errors->all())}}
        @endif--}}
        @if(session()->has('error'))
            <div class="alert alert-danger">
                <b>Sorry!</b> {{session('error')}}
            </div>
            <br>
        @endif
        <form class="login-form" id="loginForm" method="post" action="{{route('loginSubmit')}}" novalidate>

            @csrf
            <div class="form-group {{$errors->has('email')? 'error' : ''}}">
                <div class="input-wrapper">
                    <input type="email" id="email" name="email"  autocomplete="email" value="{{old('email')}}">
                    <label for="email">Business Email</label>
                    <span class="input-border"></span>
                </div>
                <span class="error-message {{$errors->has('email') ? 'show' : ''}}" id="emailError">{{$errors->first('email')}}</span>
            </div>

            <div class="form-group {{$errors->has('password') ? 'error' : ''}}">
                <div class="input-wrapper password-wrapper">
                    <input type="password" id="password" name="password"  autocomplete="current-password">
                    <label for="password">Password</label>
                    <button type="button" class="password-toggle" id="passwordToggle" aria-label="Toggle password visibility">
                        <span class="toggle-icon"></span>
                    </button>
                    <span class="input-border"></span>
                </div>
                <span class="error-message {{$errors->has('password') ? 'show': ''}}" id="passwordError">{{$errors->first('password')}}</span>
            </div>

           {{-- <div class="form-options">
                <div class="remember-wrapper">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember" class="checkbox-label">
                        <span class="checkbox-custom"></span>
                        Keep me signed in
                    </label>
                </div>
                <a href="#" class="forgot-password">Reset password</a>
            </div>--}}

            <button type="submit" class="login-btn">
                <span class="btn-text">Sign In</span>
                <span class="btn-loader"></span>
            </button>
        </form>
    </div>
</div>

<script src="{{ asset('login/form-utils.js') }}"></script>
<script>
    class CorporateLoginForm {
        constructor() {
            this.form = document.getElementById('loginForm');
            this.emailInput = document.getElementById('email');
            this.passwordInput = document.getElementById('password');
            this.passwordToggle = document.getElementById('passwordToggle');
            this.submitButton = this.form.querySelector('.login-btn');
            this.successMessage = document.getElementById('successMessage');
            this.ssoButtons = document.querySelectorAll('.sso-btn');

            this.init();
        }
        init() {
            this.bindEvents();
            this.setupPasswordToggle();
            this.setupSSOButtons();
        }
        bindEvents() {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
            //his.emailInput.addEventListener('blur', () => this.validateEmail());
            //this.passwordInput.addEventListener('blur', () => this.validatePassword());
            //this.emailInput.addEventListener('input', () => this.clearError('email'));
            //this.passwordInput.addEventListener('input', () => this.clearError('password'));
        }

        setupPasswordToggle() {
            this.passwordToggle.addEventListener('click', () => {
                const type = this.passwordInput.type === 'password' ? 'text' : 'password';
                this.passwordInput.type = type;

                const icon = this.passwordToggle.querySelector('.toggle-icon');
                icon.classList.toggle('show-password', type === 'text');
            });
        }

        setupSSOButtons() {
            this.ssoButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    const provider = button.classList.contains('azure-btn') ? 'Azure AD' : 'Okta';
                    this.handleSSOLogin(provider);
                });
            });
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        new CorporateLoginForm();
    });

</script>
{{--<script src="login/script.js"></script>--}}
</body>

<!-- Mirrored from puikinsh.github.io/login-forms/forms/corporate/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Sep 2025 17:48:05 GMT -->
</html>
