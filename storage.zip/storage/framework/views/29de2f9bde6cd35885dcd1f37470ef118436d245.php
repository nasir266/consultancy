<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('RCZjruh')) {
    $componentId = $_instance->getRenderedChildComponentId('RCZjruh');
    $componentTag = $_instance->getRenderedChildComponentTagName('RCZjruh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RCZjruh');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('RCZjruh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH D:\laravel\nn_pos\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>